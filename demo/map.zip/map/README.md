# 使用
1. windows

    直接运行server.exe

    浏览 http://127.0.0.1:8090/index
    
2. linux

    sudo chmod +x server (ubuntu)
    
    直接运行 ./server

    浏览 http://127.0.0.1:8090/index

# 高德
1. 搜索最近的点 

   点击地图，显示最近的5公里范围内的7个点

   中心点大概在上海，随机生成的300个点

2. Cluster todo

3. Heatmap todo

# google 
需要科学上网
1. K-Nearest (click on a map to show the k-nearest points)

2. Cluster

3. Heatmap